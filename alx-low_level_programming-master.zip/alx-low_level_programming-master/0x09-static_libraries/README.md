**0x09. C - Static libraries**
