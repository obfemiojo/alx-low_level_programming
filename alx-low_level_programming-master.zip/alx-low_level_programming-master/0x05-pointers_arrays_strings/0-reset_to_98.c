#include "holberton.h"
/**
 * reset_to_98 - use a pointer to update the value of an integer
 * @n: parameter
 * Descriiption - reset_to_98 resets the value of *n to 98
 */
void reset_to_98(int *n)
{
	*n = 98;
}
