#include "holberton.h"

/**
 *  mul - a function that multiplies two integers
 * @a: first input
 * @b: second input
 * Return: multiplication result of the 2 inputs
 */
int mul(int a, int b)
{
	return (a * b);
}
