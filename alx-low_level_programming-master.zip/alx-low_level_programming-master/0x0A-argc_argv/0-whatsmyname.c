/*
 * File: 0-whatsmyname.c
 * Author: Ukonu, Divine Chisom
 *
 */

#include <stdio.h>

/**
 * main - A program that prints it's name, folloewd by a new line.
 * @argc: The argument count
 * @argv: the rgument vector
 * Return: Always 0
 */
int main(int __attribute__((__unused__)) argc, char *argv[])
{
	printf("%s\n", argv[0]);

	return (0);
}
