#ifndef HOLBERTON_H
#define HOLBERTON_H

int _putchar(char c);




#endif
