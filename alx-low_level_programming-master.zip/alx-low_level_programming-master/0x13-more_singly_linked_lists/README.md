**0x13. C - More singly linked lists**
