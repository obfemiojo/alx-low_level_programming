#include <stdio.h>

/**
 * main - main function
 * Description: Print numbers 0 - 5
 * Return: 0
 */

int main(void)
{
	int i;

	for (i = 0; i < 10; i++)
		printf("%d", i);
	putchar('\n');
	return (0);
}
