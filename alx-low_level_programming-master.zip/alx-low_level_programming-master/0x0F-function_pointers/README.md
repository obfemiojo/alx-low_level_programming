0x0F. C - Function pointers
