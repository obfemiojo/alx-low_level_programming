0. Prints ``Holberton`` followed by a new line, and returns 0.

1. Prints the lowercase letters of the alphabet followed by a new line

2. Prints the alphabet ten times, using ``_putchar`` only twice.

3. Checks for a lowercase character. Recreation of ``islower``

4. Checks for an alphabetic character. Recreation of ``isalpha``

5. Prints the sign of a number

6. Computes the absolute value of an integer

7. Prints the last digit of a number

8. Prints all times from 00:00 to 23:59

9. Prints the 9 times table, starting with zero

10. Adds 2 integers and returns the result

11. Prints all numbers from n to 98

12. Prints the n times table, starting with zero

13. Computes and prints the sum of all the multiples of 3 or 5 below 1024

14. Prints the first 50 Fibonacci numbers starting with 1 and 2

15. Computes and prints the sum of all even Fibonacci numbers under 4 million.

16. Computes and prints the first 98 Fibonacci numbers
