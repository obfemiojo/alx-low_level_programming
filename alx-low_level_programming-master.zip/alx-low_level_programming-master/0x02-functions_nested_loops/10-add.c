#include "holberton.h"
/**
 * add - adds two numbers together.
 * @i: The first number to be added.
 * @j: The second number to be added.
 * Return: the sum of two numbers.
 */
int add(int i, int j)
{
	return (i + j);
}
